package uz.schoolrank.schoolrank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolRankApplicationTests {

    @Test
    void contextLoads() {
    }

}
