package uz.schoolrank.schoolrank.entity;

import uz.schoolrank.schoolrank.entity.template.AbsUUIDNoUser;
import uz.schoolrank.schoolrank.enums.LanguageName;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

public class Language extends AbsUUIDNoUser {

    @Column(nullable = false, name = "name")
    @Enumerated(EnumType.STRING)
    private LanguageName languageName;

}
