package uz.schoolrank.schoolrank.enums;

public enum AuthProviderName {

    GOOGLE,

    FACEBOOK

}
