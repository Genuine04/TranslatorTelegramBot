package uz.schoolrank.schoolrank.entity;

import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;
import uz.schoolrank.schoolrank.entity.template.AbsUUID;
import uz.schoolrank.schoolrank.enums.LanguageName;

import javax.persistence.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
@DynamicInsert
@DynamicUpdate
@EqualsAndHashCode(callSuper = true)
@Entity(name = "school")
@Where(clause = "deleted=false")
@SQLDelete(sql = "UPDATE role SET deleted=true WHERE id=?")
public class School extends AbsUUID {

    @Column(nullable = false, name = "name")
    private String name;

    @Column(nullable = false, name = "description", columnDefinition = "text")
    private String description;

    @Column(name = "website")
    private String website;

    @Column(nullable = false, name = "email")
    private String email;

    @Column(nullable = false, name = "phone_number")
    private String phoneNumber;

    @Column(nullable = false, name = "fax")
    private String fax;

    @OneToOne(optional = false)
    private User user;

    @OneToOne(optional = false)
    private Address address;

    @OneToOne(optional = false)
    private EducationSystem system;

    @ManyToOne(fetch = FetchType.LAZY)
    private Language language;


}
