package uz.schoolrank.schoolrank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolRankApplication {

    public static void main(String[] args) {
        SpringApplication.run(SchoolRankApplication.class, args);
    }

}
