package uz.schoolrank.schoolrank.enums;

public enum LanguageName {

    UZ,
    RU

}
