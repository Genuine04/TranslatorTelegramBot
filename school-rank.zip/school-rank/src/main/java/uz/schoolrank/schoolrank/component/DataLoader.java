package uz.schoolrank.schoolrank.component;

import org.springframework.boot.CommandLineRunner;

public class DataLoader implements CommandLineRunner {



    @Override
    public void run(String... args) throws Exception {

    }
}
