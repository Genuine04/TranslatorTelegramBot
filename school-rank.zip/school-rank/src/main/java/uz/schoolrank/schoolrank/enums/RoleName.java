package uz.schoolrank.schoolrank.enums;

public enum RoleName {

    ROLE_STUDENT,

    ROLE_PARENT,

    ROLE_ADMIN

}
